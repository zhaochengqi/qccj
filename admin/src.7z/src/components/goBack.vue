<template>
    <el-button size="" type="danger" @click="goBack"> <i class="fa fa-arrow-circle-left"></i> 返回</el-button>
</template>
<script>
export default {
    methods: {
        goBack() {
            this.$router.go(-1)
        }
    }
}
</script>

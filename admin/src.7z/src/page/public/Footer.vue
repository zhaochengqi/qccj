<template>
    <footer id="footer">
        <div class="pull-right pad-rgt">
            由 <a href="http://www.ez-tech.cn" class="no-padding el-button el-button--text el-button--small" target="_blank">上海屹瑞信息科技有限公司</a> 技术强力驱动
        </div>
    </footer>
</template>

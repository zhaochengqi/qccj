<template>
    <div>
        <!-- <el-card class="box-car">
            <el-row>
            </el-row>
        </el-card> -->
    </div>
</template>
<script>
export default {
    created: function() {
        this.getData();
    },
    data() {
        return {

        }

    },
    methods: {
        getData() {

        }

    },
    computed: {}
}
</script>
